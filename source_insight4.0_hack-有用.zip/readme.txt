1.首先安装sourceinsight4087-setup.exe
2.使用下载好的sourceinsight4.exe替换已安装好的sourceinsight4.exe
3.启动sourceinsight，导入下载好的si4.pediy.lic